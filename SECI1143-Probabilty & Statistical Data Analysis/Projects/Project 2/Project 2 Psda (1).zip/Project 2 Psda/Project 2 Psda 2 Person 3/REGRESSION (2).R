#Import dataset from text base~csv file with heading(yes)

# scatter plot
plot(student_math_clean$absences,
     student_math_clean$final_grade,
     main="Scatter Plot: Absences vs Final Grade",
     xlab="Absences",
     ylab="Final Grade",
     pch=1)


# Build the linear regression model
model <- lm(final_grade ~ absences, data = student_math_clean)

# View model
model
summary(model)

# Scatter plot
plot(student_math_clean$absences,
     student_math_clean$final_grade,
     main = "Regression Line: Absences vs Final Grade",
     xlab = "Absences",
     ylab = "Final Grade",
     pch = 1)

# Regression line
abline(model)