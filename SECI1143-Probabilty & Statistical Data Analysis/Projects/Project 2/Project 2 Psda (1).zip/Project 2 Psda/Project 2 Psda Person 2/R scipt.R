dataset <- read.csv("student_math_clean.csv")


x <- ifelse(dataset$study_time == "<2 hours", 1,
            ifelse(dataset$study_time == "2 to 5 hours", 2,
                   ifelse(dataset$study_time == "5 to 10 hours", 3, 4)))

y <- dataset$final_grade





r <- cor(x, y)
r

n <- 395
df = n - 2
t_stat = r / sqrt((1 - r^2) / (n - 2))
t_stat

cor.test(x, y, method = "pearson")

model <- lm(y ~ x)


plot(x, y,
     
     ylim = c(0,20),
     xaxt = "n",
     xlab = "Study Time ",
     ylab = "Final Grade ",
     main = "Scatter Plot of Study Time vs. Final Grade")

axis(1, at = 1:4, labels = c("<2 hours", "2 to 5 hours", "5 to 10 hours", ">10 hours"))
abline(model)
