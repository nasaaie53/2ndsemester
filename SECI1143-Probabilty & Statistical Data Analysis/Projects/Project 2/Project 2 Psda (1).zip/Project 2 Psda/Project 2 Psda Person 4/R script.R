
student_data <- read.csv("student_math_clean.csv")

tbl = table(student_data$internet_access, student_data$higher_ed)
tbl

chisq_result <- chisq.test(tbl, correct=FALSE)
x2 <- chisq_result$statistic

alpha <- 0.05
x2.alpha <- qchisq(alpha, df=1, lower.tail=FALSE)


x2.pvalue <- pchisq(x2, df=1, lower.tail=FALSE)

x2.alpha
x2

x2.pvalue

tbl_result <- chisq.test(tbl, correct = FALSE)


tbl_result
