
data <- read.csv("student_math_clean.csv")


test_t <- t.test(data$final_grade ~ data$sex)

print(test_t)

