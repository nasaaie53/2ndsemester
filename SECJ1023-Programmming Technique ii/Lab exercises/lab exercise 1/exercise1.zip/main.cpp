// ? EXERCISE 1: INTRODUCTION TO CLASSES AND OBJECTS

// Programming Technique II

// Member 1's Name: _____________
// Member 2's Name: _____________
//
// Section: ___
// Member 1's Name: _____________    Location: ____________ (i.e. where are you currently located)
// Member 2's Name: _____________    Location: ____________

// Log the time(s) your pair programming sessions
//  Date         Time (From)   To             Duration (in minutes)
//  _________    ___________   ___________    ________
//  _________    ___________   ___________    ________

// Video link:
//   _________


#include <iostream>
#include <string>

using namespace std;

int main()
{
	cout << "Enter the following data: " << endl;
	cout << "  Subject name => ";
	cout << endl;

	cout << "  Subject code => ";
	cout << endl;

	cout << "  Score earned => ";
	cout << endl;

	cout << endl
		 << endl;

	cout << "THE RESULT" << endl
		 << endl;

	cout << "Subject Code : " << endl;
	cout << "Subject Name : " << endl;
	cout << "Credit Hour  : " << endl;
	cout << "Score Earned : " << endl;
	cout << "Grade Earned : " << endl;
	cout << "Grade Point  : " << endl;
	cout << "Point Earned : " << endl;
	cout << endl;

	system("pause");

	return 0;
}
