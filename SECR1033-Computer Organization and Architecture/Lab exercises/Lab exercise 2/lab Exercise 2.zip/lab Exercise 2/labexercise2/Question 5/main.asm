INCLUDE Irvine32.inc

.code
main PROC
    MOV DX, 0        
    MOV AX, 1000h   
    MOV CX, 25h     
    MUL CX           

    CALL DumpRegs  
    exit
main ENDP
END main