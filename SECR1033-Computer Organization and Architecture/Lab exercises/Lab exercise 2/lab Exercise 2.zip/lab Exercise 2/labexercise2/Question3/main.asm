include irvine32.inc 
.data 
var1 DWORD 5 
var2 DWORD 10 
var3 DWORD 20 
var4 DWORD ? 
 
.code 
main proc 
mov eax, var1 
mul var2 
add eax, var3 
dec eax 
mov var4, eax
call DumpRegs
exit 
main endp 
end main 