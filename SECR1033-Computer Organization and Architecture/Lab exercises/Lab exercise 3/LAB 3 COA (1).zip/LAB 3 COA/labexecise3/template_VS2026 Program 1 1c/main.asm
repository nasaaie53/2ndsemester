INCLUDE irvine32.inc

.data

strTitle BYTE "Calculate Perimeter 2 - Hexagon (LOOP and ADD instructions): ",0
strinput BYTE "Input Hexagon 1 ( side lenght ): ",0
strResult BYTE "Result of Perimeter Hexagon 1 and 2: ",0
strTotal BYTE "Total Perimeter Hexagon 1 and 2 ", 0

sideHex1 DWORD ?
sideHex DWORD ?
Perimeter_hexagon1 DWORD 0
Perimeter_hexagon2 DWORD 0
TotalPerimeter DWORD 0

.code
main PROC

mov edx,OFFSET strinput1
call WriteString
call ReadDec
mov sideHex1, eax


mov edx,OFFSET strinput2
call WriteString
call ReadDec
mov sideHex2,eax
call Crlf


mov ecx,6
mov eax,0
CalcHex1:
add eax,sideHex1
loop CalcHex1
mov Perimeter_hexagon1,eax

mov ecx,6;
mov eax,0
CalcHex2:
add eax,sideHex2
loop CalcHex2
mov Perimeter_hexagon2

(Perimeter_hexagon1 + Perimeter_hexagon2)
mov eax,Perimeter_hexagon1
add eax,Perimeter_hexagon2
mov TotalPerimeter,eax

mov edx,OFFSET strResult
call WriteString
call Crlf

mov eax,Perimeter_hexagon1
call WriteDec
call Crlf

mov eax,Perimeter_hexagon2
call WriteDec
call Crlf
call Crlf

mov edx,OFFSET strTotal
call WriteString
mov eax,TotalPerimeter
call WriteDec
call Crlf

exit
main ENDP
END main




