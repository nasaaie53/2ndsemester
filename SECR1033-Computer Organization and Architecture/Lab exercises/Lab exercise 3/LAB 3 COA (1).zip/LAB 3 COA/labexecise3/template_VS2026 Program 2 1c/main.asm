INCLUDE Irvine32.inc

.data
    ; Prompts and Display Strings
    titleStr     BYTE "Calculate SUM (unsign INT) index (Odd or Even) in array Hello[6] :", 0
    inputPrompt  BYTE "Interger Input : ", 0
    resultTitle  BYTE "Result Sum Hello[index]:", 0
    evenResult   BYTE "Sum Hello[even] index location : ", 0
    oddResult    BYTE "Sum Hello[odd] index location : ", 0
    
    ; Variables and Arrays
    HELLO        DWORD 6 DUP(?)    ; Array to store 6 unsigned double-word integers
    TotalEVEN    DWORD 0           ; To store the sum of even indices (HELLO[0], HELLO[8], HELLO[16])
    TotalODD     DWORD 0           ; To store the sum of odd indices (HELLO[4], HELLO[12], HELLO[20])

.code
main PROC
    ; -------------------------------------------------------------------------
    ; STEP 1: Title Display
    ; -------------------------------------------------------------------------
    mov edx, OFFSET titleStr
    call WriteString
    call Crlf
    call Crlf

    ; -------------------------------------------------------------------------
    ; STEP 2: Interactively read 6 integers from the user using a LOOP
    ; -------------------------------------------------------------------------
    mov ecx, 6                      ; Set loop counter to 6
    mov esi, 0                      ; Initialize ESI as the byte offset pointer (0, 4, 8, ...)

InputLoop:
    ; Display input prompt
    mov edx, OFFSET inputPrompt
    call WriteString
    
    ; Read unsigned 32-bit integer from keyboard into EAX
    call ReadDec                    
    
    ; Store the input into the array at the current offset
    mov HELLO[esi], eax             
    
    ; Advance the pointer to the next DWORD element (4 bytes forward)
    add esi, 4                      
    loop InputLoop

    call Crlf

    ; -------------------------------------------------------------------------
    ; STEP 3: Process and sum elements using a LOOP instruction
    ; -------------------------------------------------------------------------
    ; The even elements are at byte offsets: 0, 8, 16
    ; The odd elements are at byte offsets: 4, 12, 20
    ; We can loop 3 times, adding 8 bytes to our offset pointers in each iteration.
    
    mov ecx, 3                      ; 3 pairs of elements to add
    mov esi, 0                      ; Pointer for Even elements (starts at HELLO[0])
    mov edi, 4                      ; Pointer for Odd elements (starts at HELLO[4])

SumLoop:
    ; Accumulate Even Index Elements
    mov eax, HELLO[esi]
    add TotalEVEN, eax
    
    ; Accumulate Odd Index Elements
    mov ebx, HELLO[edi]
    add TotalODD, ebx
    
    ; Advance offsets by 8 bytes to target the next element in the same group
    ; Even jumps: 0 -> 8 -> 16
    ; Odd jumps:  4 -> 12 -> 20
    add esi, 8                      
    add edi, 8                      
    loop SumLoop

    ; -------------------------------------------------------------------------
    ; STEP 4: Display Output Results
    ; -------------------------------------------------------------------------
    mov edx, OFFSET resultTitle
    call WriteString
    call Crlf
    call Crlf

    ; Display Even Index Sum
    mov edx, OFFSET evenResult
    call WriteString
    mov eax, TotalEVEN
    call WriteDec
    call Crlf

    ; Display Odd Index Sum
    mov edx, OFFSET oddResult
    call WriteString
    mov eax, TotalODD
    call WriteDec
    call Crlf

    exit
main ENDP
END main