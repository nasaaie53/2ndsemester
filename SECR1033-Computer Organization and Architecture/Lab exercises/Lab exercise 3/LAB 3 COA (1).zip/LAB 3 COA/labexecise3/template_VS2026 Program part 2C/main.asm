INCLUDE Irvine32.inc

.data
    menuMsg1 BYTE "Welcome to Simple Math Activities:", 0dh, 0ah, 0
    menuMsg2 BYTE "(Main Menu):", 0dh, 0ah, 0
    menuMsg3 BYTE "1. To calculate Perimeter Hexagon (Loop and ADD instructions)", 0dh, 0ah, 0
    menuMsg4 BYTE "2. To calculate SUM (unsign int) index (Odd or Even) in an Array Hello [6]", 0dh, 0ah, 0
    menuMsg5 BYTE "Select Your Input: ", 0
    contMsg  BYTE "Continue - type (y) and Exit type (n): y or n: ", 0
    byeMsg   BYTE "Thank you ... BYE !!!", 0

    prog1Title BYTE "Calculate Perimeter 2-Hexagon (LOOP and ADD instructions): ", 0dh, 0ah, 0
    p1In1      BYTE "Input Hexagon 1 (side length) : ", 0
    p1In2      BYTE "Input Hexagon 2 (side length) : ", 0
    p1ResTitle BYTE "Result of Perimeter Hexagon 1 and 2: ", 0dh, 0ah, 0
    p1TotalMsg BYTE "Total Perimeter Hexagon 1 and 2: ", 0
    
    sideHex1 DWORD ?
    sideHex2 DWORD ?
    Perimeter_hexagon1 DWORD ?
    Perimeter_hexagon2 DWORD ?
    TotalPerimeter DWORD ?

    prog2Title BYTE "Calculate SUM (unsign INT) index (Odd or Even) in array Hello[6] :", 0dh, 0ah, 0
    p2In       BYTE "Integer Input : ", 0
    p2ResTitle BYTE "Result Sum Hello[index]:", 0dh, 0ah, 0
    p2ResEven  BYTE "Sum Hello[even] index location : ", 0
    p2ResOdd   BYTE "Sum Hello[odd] index location : ", 0
    
    HELLO DWORD 6 DUP(?)
    TotalEVEN DWORD ?
    TotalODD DWORD ?

.code
main PROC

MainMenu:
    call Clrscr
    mov edx, OFFSET menuMsg1
    call WriteString
    call Crlf
    
    mov edx, OFFSET menuMsg2
    call WriteString
    call Crlf
    
    mov edx, OFFSET menuMsg3
    call WriteString
    
    mov edx, OFFSET menuMsg4
    call WriteString
    call Crlf
    
    mov edx, OFFSET menuMsg5
    call WriteString
    
    call ReadDec
    
    cmp eax, 1
    je periHex_loopAdd
    
    cmp eax, 2
    je calSum_oddeven
    
    jmp PromptContinue

periHex_loopAdd:
    call Clrscr
    mov edx, OFFSET prog1Title
    call WriteString
    call Crlf

    mov edx, OFFSET p1In1
    call WriteString
    call ReadDec
    mov sideHex1, eax
    
    mov edx, OFFSET p1In2
    call WriteString
    call ReadDec
    mov sideHex2, eax
    call Crlf

    mov ecx, 6
    mov eax, 0
    mov ebx, sideHex1
L1:
    add eax, ebx
    loop L1
    mov Perimeter_hexagon1, eax

    mov ecx, 6
    mov eax, 0
    mov ebx, sideHex2
L2:
    add eax, ebx
    loop L2
    mov Perimeter_hexagon2, eax

    mov ebx, Perimeter_hexagon1
    add ebx, Perimeter_hexagon2
    mov TotalPerimeter, ebx

    mov edx, OFFSET p1ResTitle
    call WriteString
    
    mov eax, Perimeter_hexagon1
    call WriteDec
    call Crlf
    
    mov eax, Perimeter_hexagon2
    call WriteDec
    call Crlf
    call Crlf
    
    mov edx, OFFSET p1TotalMsg
    call WriteString
    mov eax, TotalPerimeter
    call WriteDec
    call Crlf
    call Crlf

    jmp PromptContinue

calSum_oddeven:
    call Clrscr
    mov edx, OFFSET prog2Title
    call WriteString
    call Crlf
    
    mov ecx, 6
    mov esi, 0
Input_Loop:
    mov edx, OFFSET p2In
    call WriteString
    call ReadDec
    mov HELLO[esi], eax
    add esi, 4
    loop Input_Loop
    call Crlf

    mov eax, 0
    mov ecx, 3
    mov esi, 0
Even_Loop:
    add eax, HELLO[esi]
    add esi, 8
    loop Even_Loop
    mov TotalEVEN, eax

    mov eax, 0
    mov ecx, 3
    mov esi, 4
Odd_Loop:
    add eax, HELLO[esi]
    add esi, 8
    loop Odd_Loop
    mov TotalODD, eax

    mov edx, OFFSET p2ResTitle
    call WriteString
    call Crlf
    
    mov edx, OFFSET p2ResEven
    call WriteString
    mov eax, TotalEVEN
    call WriteDec
    call Crlf
    
    mov edx, OFFSET p2ResOdd
    call WriteString
    mov eax, TotalODD
    call WriteDec
    call Crlf
    call Crlf

    jmp PromptContinue

PromptContinue:
    mov edx, OFFSET contMsg
    call WriteString
    
    call ReadChar
    call WriteChar
    call Crlf
    
    cmp al, 'y'
    je MainMenu
    cmp al, 'Y'
    je MainMenu
    
    mov edx, OFFSET byeMsg
    call WriteString
    call Crlf
    exit

main ENDP
END main